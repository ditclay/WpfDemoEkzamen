﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sport.Classes
{
    class connect
    {
        public static Models.SportMagazEntities modelbd;
    }
}
